Copy-Item out/artifacts/PracticaPL_jar/PracticaPL.jar pruebas/PracticaPL.jar
java -jar pruebas/PracticaPL.jar pruebas/prueba.txt