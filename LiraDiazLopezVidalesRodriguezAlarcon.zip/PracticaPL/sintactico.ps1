cd src/analyzers
java -jar ../../java-cup/java-cup-11b.jar .\aSintactico.cup
cd ../../