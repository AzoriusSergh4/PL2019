package analyzers;

public class Variable {
    private String vars;

    public Variable(String vars) {
        this.vars = vars;
    }

    public String getVars() {
        return vars;
    }
}
