Copy-Item out/artifacts/PL2019_jar/PL2019.jar pruebas/PL2019.jar
